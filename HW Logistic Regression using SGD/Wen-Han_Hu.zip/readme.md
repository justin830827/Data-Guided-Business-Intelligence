The Logistic_Regression_using_SGD.py includes the implementation of SDG and driver as well as unittest.
For the unittest, I used the function from sklearn to see ther result if match.

Instruction to run the script:

python3 Logistic_Regression_using_SGD.py

Required package:
sklearn.dataset
sklearn

Reference:
https://www.youtube.com/watch?v=8lJ6IU028k8 