README

Wen-Han Hu/Justin (whu24)

This zip file includes the screenshots from models, the pdf file of Logistic regression, the the soource code in R. This R code requore libriay at the begining of script.  
The result may be different depending on the seed of train dataset. The defaulted seed = 123. 